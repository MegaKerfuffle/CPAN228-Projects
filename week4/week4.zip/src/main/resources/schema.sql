CREATE TABLE dish(
    id INT auto_increment,
    name VARCHAR(20),
    category VARCHAR(20),
    price DOUBLE
);