INSERT INTO dish(name, category, price)
VALUES
    ('Pizza', 'Non-Veg', 12),
    ('Chicken Sandwich', 'Non-Veg', 18),
    ('Shawarma', 'Vegan', 10);